import React from "react";
import "../../App.css";

export default function Contact() {
    return <h1 className="contact">LIKE & CONTACT</h1>;
}
