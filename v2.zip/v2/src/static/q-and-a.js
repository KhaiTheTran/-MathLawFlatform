export default {
    questionsAndAnswers: [
        {
            name: "Housing Law",
            description: "Issues with landlords, subleasing, etc...",
            qa: [
            {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                }
            ],
        },
        {
            name: "Immigration Law",
            description: "Issues with landlords, paperwork for school, applying to work, etc...",
            qa: [
            {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                }
            ],
        },
        {
            name: "Housing Law",
            description: "Parents and dependency, divorce, custody, etc...",
            qa: [
            {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                }
            ],
        },
        {
            name: "Bankruptcy Law",
            description: "Student loan issues, debt, etc...",
            qa: [
            {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                }
            ],
        },
        {
            name: "Criminal Law",
            description: "Speeding ticket, arrested, bail information, public defenders, etc...",
            qa: [
            {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                },
                {
                    question: "Flower Hua",
                    answer: "Flower"
                }
            ],
        },
    ]
};